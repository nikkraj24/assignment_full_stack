import express from "express";
import bodyParser from "body-parser";
import axios from "axios";
import https from "https";


const app = express()
app.set('view engine','ejs')

const API_URL = "https://qa2.sunbasedata.com/sunbase/portal/api";

const user = "test@sunbasedata.com";
const pass = "Test@123";
const token = "dGVzdEBzdW5iYXNlZGF0YS5jb206VGVzdEAxMjM=";

const config = {
    headers: { Authorization: `Bearer ${token}` },
};

app.use(express.static("public"));
app.use(bodyParser.urlencoded({
  extended: true
}));

app.get('/', (req, res) => {
  res.render("main.ejs");
})

app.get('/add', (req, res) => {
    res.render("addcustomer.ejs");
})

app.post('/add',async (req,res)=>{
      try {
        const result = await axios.post("https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp?cmd=create",req.body, config);
        res.render("success.ejs");
      } catch (error) {
        res.status(404).send(error.message);
      }
})
app.post("/", async function(req, res) {
    if(req.body.username==="test@sunbasedata.com" && req.body.password==="Test@123"){
        try {
            const result = await axios.get("https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp?cmd=get_customer_list", config);
            res.render("viewcustomer.ejs", { content: result.data });
          } catch (error) {
            res.status(404).send(error.message);
          }
    }
})

app.post('/update',async (req,res)=>{
  const id=req.body.checkbox2;
  res.render("updatecustomer.ejs", { content: id });
})

app.post('/update-update',async (req,res)=>{
  const uuid=req.body.id;
  console.log(req.body);
  try {
    const result = await axios.post(
     "https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp?cmd=update&uuid="+uuid,
      req.body, 
      config
    );
    res.render("success.ejs");
  } catch (error) {
    res.status(404).send(error.message);
  }
})

app.post('/delete',async(req,res)=> {
    let x=req.body.checkbox;
    let urll="https://qa2.sunbasedata.com/sunbase/portal/api/assignment.jsp?cmd=delete&uuid="+x;
    console.log(urll);
    try {
        const result = await axios.post(urll,req.body, config);
        res.render("success.ejs");
      } catch (error) {
        res.status(404).send(error.message);
      }
});

app.listen(process.env.PORT||3000, () => {
  console.log(`App listening on port`)
})


